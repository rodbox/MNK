<?php
/**
 * System Events Estonian lexicon topic
 *
 * @language et
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Puhasta';
$_lang['error_log'] = 'Veateadete logi';
$_lang['error_log_desc'] = 'MODX Revolution-i veateadete logi:';
$_lang['system_events'] = 'Süsteemi Event-id';
$_lang['priority'] = 'Prioriteet';
