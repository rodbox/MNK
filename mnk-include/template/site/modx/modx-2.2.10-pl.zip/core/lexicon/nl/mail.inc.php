<?php
/**
 * Mail Dutch lexicon topic
 *
 * @language nl
 * @package modx
 * @subpackage lexicon
 * 
 * @author Bert Oost at OostDesign.nl <bert@oostdesign.nl>
 */
$_lang['mail_err_address_ns'] = 'Je moet een geldig e-mailadres opgeven om naar te versturen.';
$_lang['mail_err_derive_getmailer'] = 'Poging om abstracte functie _getMailer() in modMail aan te roepen. Je moet deze functie implementeren in een afgeleide van modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] is geen geldig PHPMailer attribuut en wordt genegeerd bij uitvoering.';

$_lang['mail_err_unset_spec'] = 'modPHPMailer bied geen ondersteuning voor het uitschakelen van een specifiek adres. Gebruik reset() om alle ontvangers te legen en voeg degene toe waar naar toe je wilt versturen.';