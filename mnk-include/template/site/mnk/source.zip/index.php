<?php
require_once('mnk-include/core/mnk-core.php');
new mnk();

session_start();

theme::getIndex();
?>