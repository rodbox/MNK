<p>La page n'existe plus !</p>
<?php mnk::ilink("page:home","retour vers l'accueil") ?>