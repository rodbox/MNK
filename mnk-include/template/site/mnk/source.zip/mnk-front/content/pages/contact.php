<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="grid_8 ">
<div class=" grid_title">
    <h1>Contact</h1>
   

</div>
    <?php theme::view("contact_list","user_contact_search");?>
</div>
 