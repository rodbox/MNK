<!DOCTYPE HTML>
<html lang="fr-FR">
    <head>
        <meta charset="UTF-8">
        <title>Metronic</title>
        <?php
        mnk::css(array(
            "metro-plugins:bootstrap/css/bootstrap.min",
            "metro-plugins:bootstrap/css/bootstrap-responsive.min",
            "metro-plugins:font-awesome/css/font-awesome.min",
            "metro-plugins:uniform/css/uniform.default",
            "pack:pack-manager/pack-manager",
            "pack:uifinder/uifinder",
            "pack:snippet-manager/snippet-manager",
            "pack:toodoo/toodoo",
            "metro:style",
            "metro:themes/default",
            "metro:style-metro",
            "metro:style-responsive",
            "metro-plugins:font-awesome/css/font-awesome.min",
            "metro-plugins:gritter/css/jquery.gritter",
            "theme:style",
            "theme:color-ui",
            "theme:upload",
            "theme:ui-date-picker",
            "theme:ui-autocomplete",
            "theme:metro-tile",
            "theme:metro-sidebar",
            "theme:metro-header",
            "theme:bootstrap-fix"
        ));

        theme::favicon();
    

mnk::js(
    array(
        "core:jquery",
        "metro-plugins:jquery-validation/dist/jquery.validate.min",
        "core:jquery.mnk-livelink",
        "core:jquery.mnk-liveform",
        "core:jquery.mnk-localsearch",
        
        "metro-plugins:bootstrap/js/bootstrap.min",
        "metro-plugins:jquery-ui/jquery-ui-1.10.1.custom.min",
        "metro-plugins:gritter/js/jquery.gritter.min",
        "pack:admin/admin",
        "pack:pack-manager/pack-manager",
        "pack:site-manager/site-manager",
        "pack:theme-manager/theme-manager",
 
        "pack:basket-manager/basket-manager",
        "pack:css-grid-generator/css-grid-generator",
        "pack:doc/doc",
        "pack:snippet-manager/snippet-manager",
        "pack:toodoo/toodoo",
        "pack:uifinder/uifinder",
        "plugins:plupload/js/plupload",
        "plugins:plupload/js/plupload.html5",

        "theme:metro"

    )
    );
mnk::pack_config("toodoo");
?>
    </head>
  <body id="body-fullscreen" class="fixed-top">

   <!-- BEGIN HEADER -->
   <div class="header navbar navbar-inverse navbar-fixed-top ">
      <!-- BEGIN TOP NAVIGATION BAR -->
      <div class="navbar-inner">
         <div class="container-fluid">
           
            <a href="javascript:;" class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
             <?php ui::img('menu4','16', 'fff'); ?>
            </a>          
            
            <?php mnk::iview("theme:navigation_top"); ?>
            <?php metro::sideRight("toodoo","checkbox","pumpkin","pack:toodoo/toodoo"); ?>
      <!-- END TOP NAVIGATION BAR -->
   </div>
   <!-- END HEADER -->
   <!-- BEGIN CONTAINER -->   
   <div class="page-container row-fluid sidebar-closed">
      <!-- BEGIN SIDEBAR -->
<?php mnk::iview("theme:side_bar"); ?>
      <!-- END SIDEBAR -->
      <!-- BEGIN PAGE -->
      <div class="page-content">
        <div class="arrow-down-pumpkin"></div>
         <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
 <?php mnk::iview("theme:portlet"); ?>        
         </div>
         <!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->
            <div class="row-fluid">
               <!-- <div class="span12">
                  <h1>Dashboard</h1>
                
               </div> -->
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN CHART PORTLETS-->
            <div class="row-fluid">
                <?php mnk::fil("theme:navigation_fil"); ?>  
                <?php mnk::title("root","root-index"); ?>
                
           