<?php 
if ($_GET['live'] == true)
    mnk::chooseInc();

else {
    theme::getHeader();
    mnk::chooseInc();
    theme::getFooter();
} ?>

     