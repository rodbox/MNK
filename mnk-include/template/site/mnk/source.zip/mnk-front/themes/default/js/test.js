$(document).ready(function() {

/*$(window).unload(function() {
alert('Handler for .unload() called.');
});
*/

// window.onbeforeunload = function() { console.log($(".sidebar-closed").length);};
})

