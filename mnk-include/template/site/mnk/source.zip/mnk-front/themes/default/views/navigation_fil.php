<ul class="breadcrumb">
                <li>
                    <i class="icon-home"></i>
                   <?php mnk::ilink("page:home"); ?>Home</a> 
                                        
                    <i class="icon-angle-right"></i>
                                    </li>
                                    
                                <li><a href="#">Visual Charts</a></li>  
                        
                        
            </ul>