<ul class="nav pull-right">
<li>	<?php 
		metro::modalLinkMini("pack-creator","plus","Créer un pack","transparent");
		metro::modal("pack-creator","Créer un pack","pack:pack-manager/pack-creator"); 
	?>
</li>
<li><?php 
	metro::modalLinkMini("pack-file-creator","file-plus2","Créer un fichier de pack","transparent");
	metro::modal("pack-file-creator","Créer un fichier de pack","pack:pack-manager/pack-file-creator","pack-list"); 
?></li>

   <?php //mnk::iview("theme:navigation_top_speed-link"); ?>
   <?php mnk::iview("theme:navigation_top_calendar"); ?>

<!-- BEGIN NOTIFICATION DROPDOWN -->   
<?php //mnk::iview("theme:navigation_top_notifications"); ?>
<!-- END NOTIFICATION DROPDOWN -->
<?php //mnk::iview("theme:navigation_top_inbox"); ?>

<!-- BEGIN TODO DROPDOWN -->
<?php //mnk::iview("theme:navigation_top_task"); ?>

<!-- END TODO DROPDOWN -->

<?php mnk::iview("theme:navigation_top_user"); ?>


<!-- END USER LOGIN DROPDOWN -->
</ul>
<!-- END TOP NAVIGATION MENU --> 
</div>
</div>