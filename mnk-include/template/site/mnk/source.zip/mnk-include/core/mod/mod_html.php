<?php

class html extends mnk {

    function b($balise, $content, $attr = null) {
        $attribute = parent::attr($attr);
        echo "<" . $balise . " " . $attribute . ">" . $content . "</" . $balise . ">";
    }

    /*
     * function js
     * @param $src // chemin du fichier js a inclure
     */

    function js($src) {
        if (is_array($src)) {
            foreach ($src as $val)
                echo '<script src="' . $val . '" language="javascript" type="text/javascript"></script>' . "\n";
        }
        else
            echo '<script src="' . $src . '" language="javascript" type="text/javascript"></script>' . "\n";
    }

    function jsExec($cmd) {
        echo '<script language="javascript" type="text/javascript">' . $cmd . '</script>' . "\n";
    }

    function jsCore($js_file) {
        $src = CORE_JS . "/" . $js_file . ".js";
        self::js($src);
    }

    /*
     * function css
     * @param $href // chemin du fichier css a inclure
     */

    function css($href) {
        if (is_array($href)) {
            foreach ($href as $val)
                echo '<link href="' . $val . '" rel="stylesheet" type="text/css" />';
        }
        else
            echo '<link href="' . $href . '" rel="stylesheet" type="text/css" />';
    }

    function cssCore($css) {
        if (is_array($css)) {

            foreach ($css as $val)
                $href[] = CORE_CSS . "/" . $val . ".css";
        }
        else
            $href = CORE_CSS . "/" . $css . ".css";

        self::css($href);
    }

    function cssPackAdmin($packName, $cssPack = null) {

        $cssPack = ($cssPack == null) ? $packName : $cssPack;
        if (is_array($cssPack)) {
            foreach ($cssPack as $val)
                $href[] = WEB_PACK . "/" . $packName . "/admin/css/" . $val . ".css";
        }
        else
            $href = WEB_PACK . "/" . $packName . "/admin/css/" . $cssPack . ".css";

        self::css($href);
    }

}

?>
