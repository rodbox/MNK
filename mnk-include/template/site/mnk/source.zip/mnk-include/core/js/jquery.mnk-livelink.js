(function($)
{
    $.fn.mnkLiveLink=function(paramSend)
    {

      var defauts=
           {  
              start     : function(t){t.addClass("loader");},
              finish    : function(t){t.removeClass("loader");}, 
              confirm   : function(t){return true;},
              else      : function(){},
              callback  : function (data,t){
                t.addClass("check")
              }
           };  


      var param=$.extend(defauts, paramSend);

      $(document).on("click",this.selector , function (){
          var t=$(this);
          var href = t.attr("href");
          param.start(t);
         // if(param.confirm(t)){
          
            $.get(href,{"live":true},function (data){
              if(param.callback != null)
                  param.callback(data,t);




      



            })
          //}
          // else 
          //   param.else();

            param.finish(t);

    return false;
      })
    };
})(jQuery);