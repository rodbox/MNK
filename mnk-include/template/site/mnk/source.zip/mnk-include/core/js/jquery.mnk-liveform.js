(function($)
{
    $.fn.mnkLiveForm=function(options)
    {
        //On définit nos paramètres par défaut
      var defauts=
      { dataType: "html",
        before  : function (t){return true;},
        start   : function (t){t.addClass("loader");}, 
        confirm : function (){return true;},
        data    : {},
        callback: function (data,t){
            t.find("input").blur().attr({"disabled":"disabled"});
            t.find("input[type=submit]").replaceWith('ok');
        }
      };  
       
      //On fusionne nos deux objets ! =D
      var param=$.extend(defauts, options);

        

        $(document).on("submit",this.selector , function (){
          var t=$(this);
          var action = t.attr("action");
        	var dataSend = t.serialize();

          param.start(t);
          if(param.confirm()){  
            $.post(action,dataSend,function (data){
              if(param.callback != null){
                param.callback(data,t);
              }
				    },param.dataType);
          }
          return false;
          })
        }
})(jQuery);