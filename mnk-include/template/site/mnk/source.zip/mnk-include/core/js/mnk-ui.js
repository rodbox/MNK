$(document).ready(function() {
        function fullscreen(id){
            var element = document.getElementById(id);
            if(element.mozRequestFullScreen)
                element.mozRequestFullScreen(element.ALLOW_KEYBOARD_INPUT);
            else if(element.webkitRequestFullScreen)
                element.webkitRequestFullScreen(element.ALLOW_KEYBOARD_INPUT);
        }

        $('.to-fullscreen').on("click",function (){
            var t = $(this);
            var rel = t.attr("rel");

            fullscreen(rel);
            return false;
        })
        // ajoute la class "focus_label" aux labels lier par l'attribut "for" des elements de formulaire lors du focus
	

        $(document).on("click",'.pagin_footer a.pagin',function (){
            var t = $(this);
            if (!t.hasClass("curPage")){
                var contentContainer = t.parents(".pagin_container");
                t.parents(".pagin_footer").find("a.pagin.curPage").removeClass("curPage");
                var href = t.attr("href");
                t.addClass("curPage");
                
                $.post(href,function(html){
               contentContainer.html(html);
               lazy();
            })
            }
            return false;
        })
        $(document).on("click",'.pagin_footer a.pagin-next',function (){
           var t = $(this);
           $("a.pagin.curPage").next().trigger("click");
            return false;
        })

        $(document).on("click",'.pagin_footer a.pagin-prev',function (){
           var t = $(this);
           $("a.pagin.curPage").prev().trigger("click");
            return false;
        })



        $("input, select, textarea").on({
            "focus" : function (){
		var attr	= $(this).attr("name");
		$("label[for='"+attr+"']").addClass("focus-label");
            },
            "blur"  : function (){
                var attr	= $(this).attr("name");
		$("label[for='"+attr+"']").removeClass("focus-label");	
            }
        })
        
	$("a.toggle-switch").on("click",function (){
            var t = $(this);
            var href = t.attr("href");
            var dataSwitch = (t.hasClass("toggle-switch-on"))?0:1;
            
            $.post(href,{"switch":dataSwitch},function(){
                t.toggleClass("toggle-switch-on");
            })
            
            
            return false;
        })
        
       
        var msg = $("<div>").addClass('stick').html("champs obligatoire");
        // validation de formulaire
        $("form").on('submit',function(){
            var t = $(this);
            var i = 0;
            
             
            
            t.find('input.required').each(function(){
                var input = $(this);
                
                
                
                if(input.val()==""){
                   i++;
                   var posX = input.position().left;
                   var posY = input.position().top;
                   var width = input.width();
                   var msg = $("<div>").addClass("stick red").css({"top":posY,"left":posX+width}).append("champs obligatoire");
                   
                   input.addClass('alert').after(msg);

                }
                
                
            });

            return (i>0)?false:true;
        })
        
        $('input.required.alert').on('focusout',function(){
            var t = $(this);
            if(t.val()!=""){
                t.removeClass('alert');
                t.next(".stick").remove();
            }
        })
        
        
        
        
})