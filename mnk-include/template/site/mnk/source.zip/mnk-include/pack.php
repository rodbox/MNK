<?php 

    require_once('core/mnk-core.php');
    new mnk;
    session_start();

 ?>