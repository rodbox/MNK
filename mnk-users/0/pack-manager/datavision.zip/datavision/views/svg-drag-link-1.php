<rect x="10" y="10" height="100" width="100"
          style="stroke:#006600; fill: #00cc00" >

          </rect>
<text x="20" y="10">
       drag link
    </text>