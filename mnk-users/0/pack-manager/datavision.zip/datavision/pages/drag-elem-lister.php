<?php 
//mnk::iview("pack:datavision/drag-link-1");
 ?>


 <?php 
mnk::css("pack:datavision/raphaeljs-demo");
mnk::css("pack:datavision/datavision");
mnk::js("pack:datavision/raphaeljs");
mnk::js("pack:datavision/datavision");
/*mnk::js("pack:datavision/demo-drag");*/
  ?>