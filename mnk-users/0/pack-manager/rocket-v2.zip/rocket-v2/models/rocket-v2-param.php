<?php 
$d = mnk::load_json(DIR_USER_ROOT."/rocket-v2/rocket-params.json");

 ?>