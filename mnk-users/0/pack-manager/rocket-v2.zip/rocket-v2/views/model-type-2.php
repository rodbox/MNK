<div class="rocket-param-edit elem rocket-param-model hide type-2 type-elem type-child" id="new-type-2">
	<form action="#" class="type-form">
		<h2>
			<a href="#" class="toggle-me">&nbsp;</a>
			<div class="rocket-param-hook-to-parent rocket-param-hook "></div>
		<div class="type-id"></div>
			<input type="text" name="type-title"value="type-2" class="type-title">
			<div class="rocket-param-hook-to-child rocket-param-hook "></div>
			<a class="bt-resize" href="#"><?php ui::imgSVG("resize",16); ?></a>
		</h2>
		<div class="mnk-tabulator">
		<div class="menu-mini">
			<ul>
				<li><a href="#" class="speed-param-select toggled"><?php ui::imgSVG("cursor"); ?></a></li>
				<li><a href="#" class="speed-param-delete"><?php ui::imgSVG("remove8"); ?></a></li>
				<li><a href="#speed-param" class="speed-param mnk-tab-link"><?php ui::imgSVG("stack-list"); ?></a></li>
				<li><a href="#speed-param-info" class="speed-param-info mnk-tab-link"><?php ui::imgSVG("info"); ?></a></li>

				<li><a href="#speed-param-child" class="speed-param-child"><?php ui::imgSVG("share2"); ?></a></li>
				
				<li><?php form::toggle("type-link","","","","sibling","child","5","9") ?></li>
			</ul>

		</div><div class="toggle-next-target">
			<div class="mnk-tabs-list">
			<div class="speed-param mnk-tab">
				<textarea name="data-add" id="" cols="30" rows="5" class="data-speed-add"></textarea>
				<ol class="data"></ol>
			</div>
			<div class="speed-param-info mnk-tab">
				<?php form::textIco("param-info","bubble-quote","Info"); ?>
				<?php form::textIco("param-url","link","http://"); ?>
				<?php form::textIco("param-view","eye","val"); ?>
			</div>
			
		</div>
		


</div>
	</div>
	</form>
	</div>