<div class="rocket-param-edit type-0 type-elem elem rocket-param-model hide type-child toggle-me-on" id="new-type-0">
		<h2><center>
			<div class="rocket-param-hook-to-parent rocket-param-hook bg-1"></div>

			<div class="type-id"></div>
			<input type="hidden" name="type-link" value="folder"/>
			<a href="#" class="toggle-me">&nbsp;</a>
			<?php ui::imgSVG("folder4",64); ?>
			<input type="text" name="type-title" value="Function" class="type-title">

			<div class="rocket-param-hook-to-child rocket-param-hook bg-1"></div>
		</center>
		</h2>
		<div class="mnk-tabulator">
		<div class="menu-mini">
			<ul>

				<li><a href="#speed-param-info" class="speed-param-info mnk-tab-link"><?php ui::imgSVG("info"); ?></a></li>

			</ul>

		</div>
		<div class="toggle-next-target">
			<div class="mnk-tabs-list">
			<div class="speed-param-info mnk-tab">
				<?php form::textIco("type-info","bubble-quote","Info"); ?>

			</div>

		</div>

</div>
	</div>
	</div>