<div class="rocket-param-edit type-4 type-elem elem rocket-param-model hide type-child toggle-me-on" id="new-type-4">
		<h2>
			<div class="rocket-param-hook-to-parent rocket-param-hook bg-12"></div>
			<a href="#" class="toggle-me">&nbsp;</a>
			<div class="type-id"></div>
			<input type="hidden" name="type-link" value="link"/>
			<input type="text" name="type-title" value="Function" class="type-title">
			<div class="rocket-param-hook-to-child rocket-param-hook bg-12">
			</div>
			<a class="bt-resize" href="#"><?php ui::imgSVG("resize",16); ?></a>
		</h2>
		<div class="mnk-tabulator">
		<div class="menu-mini">
			<ul>

				<li><a href="#speed-param-info" class="speed-param-info mnk-tab-link"><?php ui::imgSVG("info"); ?></a></li>

			</ul>

		</div>
		<div class="toggle-next-target">
			<div class="mnk-tabs-list">
			<div class="speed-param-info mnk-tab">
				<?php form::textIco("type-info","bubble-quote","Info"); ?>
				<?php form::textIco("param-url","link","http://"); ?>
				<?php form::textIco("param-view","eye","val"); ?>
			</div>

		</div>

</div>
	</div>
	</div>