<input type="hidden" id="idDraw" value="0"/>
<svg></svg>
<div class="layer">

</div>