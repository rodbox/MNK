<div class="rocket-param-edit type-1 type-elem elem rocket-param-model hide " id="new-type-1">
		<h2>
			<input type="hidden" name="type-link" value="func"/>
			<div class="rocket-param-hook-to-parent rocket-param-hook  bg-4"></div>
			<a href="#" class="toggle-me">&nbsp;</a>
			<div class="type-id"></div>
			
			<input type="text" name="type-title" value="Function" class="type-title">
			<div class="rocket-param-hook-to-child rocket-param-hook bg-4">
			</div>
			<a class="bt-resize" href="#"><?php ui::imgSVG("resize",16); ?></a>
		</h2>
		<div class="mnk-tabulator">
		<div class="menu-mini">
			<ul>

				<li><a href="#speed-param-info" class="speed-param-info mnk-tab-link"><?php ui::imgSVG("info"); ?></a></li>

			</ul>

		</div>
		<div class="toggle-next-target">
			<div class="mnk-tabs-list">
			<div class="speed-param-info mnk-tab">
				<?php form::textIco("param-req","compass","num request param",1); ?>
				<?php form::textIco("type-info","bubble-quote","Info"); ?>
				<textarea name="type-func" id="" cols="30" rows="10" class="data-func-edit type-func"></textarea>
			</div>

		</div>

</div>
	</div>
	</div>