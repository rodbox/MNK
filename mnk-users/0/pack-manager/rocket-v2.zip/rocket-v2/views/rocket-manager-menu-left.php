<div class="sub-menu-left fixed">
	<ul>
		<li>
			<div class="menu-move">
    <a href="#up" class="move alpha_6 move-up" id="move-up"><?php ui::imgSVG("arrow-up2",12); ?></a><br>
<a href="#left" class="move alpha_6 move-left" id="move-left"><?php ui::imgSVG("arrow-left2",12); ?></a><a href="#reset" class="move alpha_6 move-reset" id="move-reset"><?php ui::imgSVG("square",6); ?></span></a><a href="#right" class="move alpha_6 move-right" id="move-right"><?php ui::imgSVG("arrow-right3",12); ?></a><br><a href="#down" class="move alpha_6 move-down" id="move-down"><?php ui::imgSVG("arrow-down2",12); ?></a>

</div>




		</li>
		<li><?php form::range("zoom","","100",25,200);?></li>
	</ul>


</div>
