<div class="mouse-menu">
	<div class="center-close center-drag">
		<div class="mouse-menu-list">
			<div class="mouse-menu-link pos_1">
				<a href="#rocket-param-select" class="trigger"><?php ui::imgSVG("cursor",32); ?></a>
			</div>
	 		<div class="mouse-menu-link pos_2">
	 			<a href="#new-type-1" class="rocket-type-add" ><?php ui::imgSVG("plus",32); ?></a>
	 		</div>
	 		<div class="mouse-menu-link pos_3">
	 			<a href="#new-type-2" class="rocket-type-add" ><?php ui::imgSVG("stack-plus",32); ?></a>
	 		</div>
	 		<div class="mouse-menu-link pos_4">
	 			<a href="#new-type-0" class="rocket-type-add"><?php ui::imgSVG("folder-plus4",32); ?></a>
	 		</div>
	 		
	 		<div class="mouse-menu-link pos_5">
	 			<a href="#new-type-3" class="rocket-type-add"><?php ui::imgSVG("plus-circle",32); ?></a>
	 		</div>
			<div class="mouse-menu-link pos_6">
	 			<a href="#new-type-4" class="rocket-type-add"><?php ui::imgSVG("plus-circle2",32); ?></a>
	 		</div>
	 		<div class="mouse-menu-link pos_7">
	 			<a href="#rocket-param-unselect" class="trigger"><?php ui::imgSVG("spinner3",32); ?></a>
	 		</div>
 		</div>
	</div>
 </div>