
<div class="sub-menu-top fixed">
<!--     <ul>
        <li><a href="#" id="addP">adddddd</a></li>
    </ul> -->
        <ul>
            
            <li class="toggled">
                <span class="menu-title">file</span>
                <ul>
                    <li>
                        <a href="#" id="param-rocket-new">
                            <?php ui::imgSVG("file2",16); ?>
                        </a>
                    </li>
                    <li><?php mnk::ilink("pack-exec:rocket-v2/rocket-v2-save #rocket-param-save"); ?><?php ui::imgSVG("disk",16); ?></a></li>
                    <li><a href="<?php echo WEB_USER_ROOT."/rocket-v2/files/my-rocket.json"; ?>" id="loading-param" ><?php ui::imgSVG("folder",16); ?></a></li>
                    <li><?php mnk::ilink("pack-exec:rocket-v2/rocket-export #rocket-param-rocket",ui::rimgSVG("rocket",16)); ?></li>
                    <!-- <li><a href="#" id="rocket-param-rocket">ui::imgSVG("rocket",16)</a></li> -->
                </ul>
            </li>
            
            <li class="toggled">
                <span class="menu-title">select</span>
                <ul>
                        <li><a href="#" id="rocket-param-select-toggle" ><?php ui::imgSVG("arrow7",16); ?></a></li>
                        <li><a href="#" id="rocket-param-select-all" ><?php ui::imgSVG("stats2",16); ?></a></li>
                        <li><a href="#type-0" class="rocket-param-select" ><?php ui::imgSVG("folder4",16); ?></a></li>
                        <li><a href="#type-1" class="rocket-param-select" ><?php ui::imgSVG("func",16); ?></a></li>
                        <li><a href="#type-2" class="rocket-param-select" ><?php ui::imgSVG("list",16); ?></a></li>
                        <li><a href="#linked" class="rocket-param-select-linked" ><?php ui::imgSVG("tree3",16); ?></a></li>
                        <li><a href="#" id="rocket-param-unselect" ><?php ui::imgSVG("spinner3",16); ?></a></li>
                        <li><a href="#" id="rocket-param-delete" ><?php ui::imgSVG("remove",16); ?></a></li>
                    </ul>
            </li>
        </ul>
        <ul><li><a href="#" id="undo" class="alpha_2 disabled"><?php ui::imgSVG("undo",16,"000"); ?></a></li>
        </ul>
        <ul>
            <li><a href="#" id="rocket-param-select" class="toggled toggled-on"><?php ui::imgSVG("cursor",16); ?></a></li>
        </ul>
        
        <ul>
            <li><a href="#" id="rocket-param-linker" class="toggled"><?php ui::imgSVG("tree3",16); ?></a></li>
            <li><a href="#" id="rocket-param-locker" class="toggled"><?php ui::imgSVG("lock4",16); ?></a></li>
        </ul>
        <ul>
            <li><a href="#" class="rocket-align" id="rocket-align-left"><?php ui::imgSVG("align-left",16); ?></a></li>
            <li><a href="#" class="rocket-align" id="rocket-align-center-horizontal"><?php ui::imgSVG("align-center-horizontal",16); ?></a></li>
            
            
            <li><a href="#" class="rocket-align" id="rocket-align-right"><?php ui::imgSVG("align-right",16); ?></a></li>
            <li><a href="#" class="rocket-align" id="rocket-align-top"><?php ui::imgSVG("align-top",16); ?></a></li>
            <li><a href="#" class="rocket-align" id="rocket-align-center-vertical"><?php ui::imgSVG("align-center-vertical",16); ?></a></li>
            
            <li><a href="#" class="rocket-align" id="rocket-align-bottom"><?php ui::imgSVG("align-bottom",16); ?></a></li>
            <li><a href="#" class="rocket-align" id="rocket-align-list-vertical"><?php ui::imgSVG("list3",16); ?></a></li>
            <li><a href="#" class="rocket-align" id="rocket-align-list-horizontal"><?php ui::imgSVG("list4",16); ?></a></li>
            <li><a href="#" class="rocket-align" id="rocket-align-grid"><?php ui::imgSVG("grid2",16); ?></a></li>
            
            <!-- 
            <li class="toggled rocket-align"><a href="#" id="rocket-align-center"><?php ui::img("align-center-horizontal",16); ?></a><ul>
                    </ul>
            </li> -->
        </ul>
        <ul>
            <li></li>
        </ul>

        <!-- <ul>
            <li><a href="#" id="uploader" class="toggled"><?php ui::img("upload7",16,"000"); ?></a></li>
        </ul>
        <ul>
                <li><a href="#" id="rocket-tools"  class="toggled">
                    <?php ui::img("tools",16); ?>
                </a></li>
            </ul> -->
        
    </div>