<?php 

extract($_POST);

$jsonDir = DIR_USER_ROOT."/rocket-v2/params/";
$jsonFile = $jsonDir."/".$file.".json";


unset($_POST['file']);

mnk::push_json($jsonFile,$_POST);

 ?>