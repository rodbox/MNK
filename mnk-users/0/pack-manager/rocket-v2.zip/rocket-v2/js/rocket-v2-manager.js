(function($) {
	$.fn.mnkDrag = function(paramSend) {

		var defauts = {
			savePos: [],
			idFunc: 0,
			idParam: 0,
			idLink: 0,
			idDraw: 0,
			onMove: false,
			lineId: 0,
			param: "",
			mouseDown: [],
			mouseDif: [],
			posOrigin: [],
			layerPosition: [],
			fixedAxis: "",
			keyMoveValue: {
				37: ["left", -10],
				38: ["top", -10],
				39: ["left", 10],
				40: ["top", 10]
			}
		};


		var param = $.extend(defauts, paramSend);

		$(document).on('mousedown', this.selector, function(e) {
			param.onMove = true;
			$("body").addClass("onMove");
			param.mouseDown = [e.clientX, e.clientY]
			param.layerPosition = $(".layer").offset();
			posOriginElem();


		})

		$(document).on('mouseup', function(e) {
			param.onMove = false;
			param.posOrigin = [];

		})



		$(document).on('mousemove', function(e) {
			if (param.onMove) {
				var difX = e.clientX - param.mouseDown[0];
				var difY = e.clientY - param.mouseDown[1];
				param.mouseDif = [difX, difY];

				param.fixedAxis = (Math.abs(difX) > Math.abs(difY)) ? "x" : "y";

				moveElem();
			}
		})


		function posOriginElem() {
			$.each($(".onSelectDrag"), function(index, val) {
				var t = $(this);
				param.posOrigin[index] = t.offset();
			});
		}


		function RemoveDupArray(a) {
			a.sort();
			for (var i = 1; i < a.length; i++) {
				if (a[i - 1] === a[i])
					a.splice(i, 1);
			}
		}


		function moveDrawLinked(t) {
			if (t.attr("reldraw")) {


				fusionList = t.attr("reldraw").split("--")

				$.each(fusionList, function(index, val) {
					var obj = val.split(",");
					var draw = $("#" + obj[0]);
					if (draw.length == 1) {
						var rel1 = draw.attr("rel1");
						var rel2 = draw.attr("rel2");
						posA = $("#" + rel1).offset();
						posB = $("#" + rel2).offset();
						var layerPos = $("svg").offset();

						var hookHA = $("#" + rel1).outerHeight() / 2;
						var hookWA = $("#" + rel1).outerWidth();

						var hookHB = $("#" + rel2).outerHeight() / 2;
						var hookWB = $("#" + rel2).outerWidth();


						draw.attr({
							'x1': posA.left - layerPos.left + hookWA,
							'y1': posA.top - layerPos.top + hookHA,
							'x2': posB.left - layerPos.left,
							'y2': posB.top - layerPos.top + hookHB
						});
					}

				});
			}



		}

		function moveElem() {
			var zoom = $("input[name=zoom]").val() / 100;
			var layerW = $(window).width();
			var layerH = $(window).height();
			var zoomDif = 1 - zoom;
			var zoomT = layerH * zoomDif;
			var zoomL = layerW * zoomDif;
			// console.log(zoomDif);
			$.each($(".onSelectDrag"), function(index, val) {
				var t = $(this);
				if (!$("body").hasClass("onAltMaj")) {
					var left = param.posOrigin[index].left * zoom + param.mouseDif[0] - param.layerPosition.left;
					var top = param.posOrigin[index].top + param.mouseDif[1] - param.layerPosition.top;

				} else {
					if (param.fixedAxis == "x") {
						var top = param.posOrigin[index].top - param.layerPosition.top;
						var left = param.posOrigin[index].left + param.mouseDif[0] - param.layerPosition.left

					} else {
						var top = param.posOrigin[index].top + param.mouseDif[1] - param.layerPosition.top;
						var left = param.posOrigin[index].left - param.layerPosition.left;

					}
				}
				t.css({
					top: top,
					left: left
				})
				moveDrawLinked(t);
			});
		}



	}
})(jQuery);



$(document).ready(function() {

	$(document).on("mousemove mouseup", function(e) {
		var t = $(".onResize");
		if (e.type == "mousemove" && !$("#rocket-param-select").hasClass("toggled-on")) {

			var pos = t.offset();
			var width = e.pageX - pos.left;
			t.width(width);
			t.find("input").width(width - 45);
			t.find("textarea").width(width - 20);
			t.find(".toggle-me").css("margin-left", width - 20);
			t.find(".rocket-param-meta-count").css("margin-left", width + 8);
			t.find(".rocket-param-hook-to-child").css("margin-left", width);
			moveDrawLinkedByThis(t);
			// console.log(width);
			// console.log(pos);
			// console.log(e);
		} else {
			t.removeClass("onResize");
			$("body").removeClass("onResizeMode");
		}
	})


	$(document).on("mousedown", "a.bt-resize", function(e) {
		$("#rocket-param-select").removeClass("toggled-on");
		$(this).parents(".rocket-param-edit").addClass("onResize");
		$("body").addClass("onResizeMode");
	})


	$(".rocket-param-edit").mnkDrag();


	$(".param-edit dt").on('click', function(e) {

		$(this).toggleClass('toggle-mini-open').next().slideToggle(125);
	});

	$(document).on('click', ".toggle-next", function() {

		$(this).toggleClass('toggle-next-open').parents(".rocket-param-edit").toggleClass('param-edit-open').find("dl").slideToggle(125);
	});



	$(".param-edit dt").addClass("toggle-mini");
	$(".rocket-param-navigator").on('change', function() {
		var t = $(this);
		var p = t.parents(".rocket-param-edit");

		var cla = 'rocket-param-' + t.val();

		p.removeClass('rocket-param-free');
		p.removeClass('rocket-param-sibling');
		p.removeClass('rocket-param-child');
		p.addClass(cla);
	});

	$(".toggle-next").on('change', function() {
		$(this).after().slideToggle();
	});

	$('.rocket-param-edit h2').dblclick(function() {
		$(this).find(".toggle-next").trigger("click")
	});
	$('#loading-param').click(function() {
		var t = $(this);
		$.getJSON(t.attr("href"), function(data) {

			$(".layer").html(data.html);
			$("#idDraw").val(data.idDraw);
			createLineForLoad();
			// addInput();
			// $(".rocket-param-hook-to-child").html("");
			$('.rocket-param-edit')
				.drop("start", function() {
					$(this).addClass("onHoverDrop");

					//					/*console.log("start");*/
				})
				.drop(function(ev, dd) {

					$(this).toggleClass("onSelectDrag");


					//					/*	console.log("drop");*/
				})
				.drop("end", function() {
					$(this).removeClass("onHoverDrop");
					//					/*console.log("drop end");*/
				}).on("mouseenter", function() {
					$("body").addClass("offDrag");
				}).on("mouseleave", function() {
					$("body").removeClass("offDrag");
				});
		})

	})

	function addInput() {
		// $("#e18").remove();
		// $("e19").remove();
		// $(".type-0 h2 img").remove();
// $("#e30-toChild").attr("reldraw","draw_39,e30-toChild,e32-toParent--");

		// var img = $("<img>",{"src":"http://metronic.excentrik.fr/mnk-include/core/img/svg/resize.svg","class":"svg-16 svg"}).css({"width":16,"height":16});
		// var linkResize  = $("<a>",{"class":"bt-resize","href":"#"}).append(img);

		// $.each($('.rocket-param-edit.type-1'),function (){
		// 	var t = $(this);
		// 	t.find(".rocket-param-hook-to-parent").remove();
		// 	var hookToParent = $("<div>",{"class":"rocket-param-hook-to-parent rocket-param-hook bg-4","id":t.attr("id")+"-toParent"});
		// 	t.find("h2").prepend(hookToParent);
		// })
		// $('.rocket-param-edit.type-1')

	}
	$('.sub-menu-top ul li.toggled, .sub-menu-top ul li a.toggled').click(function() {
		var t = $(this);
		if (t.hasClass("toggled-on"))
			t.toggleClass('toggled-on');
		else {
			$(".toggled-on").removeClass("toggled-on")
			t.addClass('toggled-on');
		}

		return false;
	})


	$('#rocket-param-save').click(function() {
		var t = $(this);
		var url = t.attr("href");
		var json = {
			"title": "my-rocket",
			"idDraw": $("#idDraw").val(),
			"html": $(".layer").html()
		}
		var i = 0;

		//		// console.log($(".line"))

		$.each($(".rocket-param-edit.elem"), function() {
			var t = $(this);
			i++;


			// var line = new Array();
			var id = t.attr("id");


			var line = i;
			json[id] = {};
			json[id]["left"] = t.css("left");
			json[id]["top"] = t.css("top");
			json[id]["toChild"] = {};
			json[id]["toParent"] = {};
			json[id]["toChild"]["reldraw"] = t.find(".rocket-param-hook-to-child").attr("reldraw");
			json[id]["toChild"]["relelem"] = t.find(".rocket-param-hook-to-child").attr("relelem");
			json[id]["toParent"]["reldraw"] = t.find(".rocket-param-hook-to-parent").attr("reldraw");
			json[id]["toParent"]["relelem"] = t.find(".rocket-param-hook-to-parent").attr("relelem");


		});
		$("body").addClass("onLoad");

        var id = $.gritter.add({
            title:"Sauvegarde", 
            text: "en cours",
            image: 'http://betty.excentrik.fr/mnk-include/core/img/ui/fff/48px/clock2.png',
            sticky: true,
            time: ''
        });


		$.post(url, json, function(data) {
	
			$.gritter.add({
				title: "Sauvegarde",
				text: "my-rocket OK",
				image: 'http://betty.excentrik.fr/mnk-include/core/img/ui/fff/48px/checkmark.png',
				sticky: false,
				time: '500'
			});
			 $.gritter.remove(id);
			$("body").removeClass("onLoad");
		});

	})
	$("#rocket-param-unselect").click(function() {
		$(".onSelectDrag").removeClass("onSelectDrag");
	})
	$("#rocket-tools").click(function() {
		$("#tools-editor").toggle();
	});

	$("#rocket-param-select-all").click(function() {
		$(".layer .elem").addClass("onSelectDrag");
	});
	$(".rocket-param-select").click(function() {
		var t = $(this);
		$(".onSelectDrag").removeClass("onSelectDrag");
		var type = t.attr("href").replace("#", ".");
		//		console.log(type);
		$(type).addClass("onSelectDrag");
	});


	$(".rocket-param-select-linked").click(function() {
		var select = $(".onSelectDrag");
		$.each(select, function() {
			var t = $(this);
			var type_1_node = exportChildNodeLoop(t.attr("id"));
			// console.log( type_1_node);
			var child = type_1_node.split("[");
			$.each(child, function(key, val) {
				var val = val.replace(new RegExp("]", "g"), '');
				$("#" + val).addClass("onSelectDrag");
			})

		})



	})


	$("#rocket-param-select-toggle").click(function() {
		$(".layer .elem").toggleClass("onSelectDrag");
	});

	$('#rocket-param-rocket').click(function() {
		var t = $(this);
		var url = t.attr("href");

		var data = {}
		data["file"] = "my-rocket";
		data["func"] = {};
		data["child"] = {};

		/* type-1 */
		var type_1_list = $(".layer .type-1");
		$.each(type_1_list, function() {

			var type_1 = $(this);
			var type_1_title = type_1.find("input.type-title").val();
			var type_1_ID = type_1.attr('id');
			var type_1_info = type_1.find("input[name=type-info]").val();
			var type_1_type = type_1.find("input[name=type-link]").val();
			var type_1_func = type_1.find("textarea.type-func").val();
			var type_1_node = exportChildNodeLoop(type_1_ID);
			if (type_1_node != "") {
				// console.log(type_1_node);
				type_1_node = type_1_node.substring(1, type_1_node.length);
				type_1_node = type_1_node.split("[");
				$.each(type_1_node, function(index, val) {
					type_1_node[index] = val.replace(new RegExp("]", "g"), '');
				});
				// type_1_node = type_1_node.splice(0);
				// console.log(type_1_node);
			}
			var type_1_req = type_1_node.length;

			data["func"][type_1_ID] = {
				"title": type_1_title,
				"id": type_1_ID,
				"helper": type_1_info,
				"func": type_1_func,
				"req": type_1_req,
				"node": type_1_node,
				"type": type_1_type
			}
		})

		/* type-child */
		var type_child_list = $(".layer .type-child");

		$.each(type_child_list, function() {

			var type_child = $(this);
			var type_child_title = type_child.find("input.type-title").val();
			var type_child_ID = type_child.attr('id');
			var type_child_info = type_child.find("input[name=type-info]").val();
			var type_child_view = type_child.find("input[name=param-view]").val();

			var type_child_type = type_child.find("input[name=type-link]").val();
			if (type_child.find("input[name=type-link]").attr("type") == "hidden")
				var type_child_type = type_child.find("input[name=type-link]").val();
			else
				var type_child_type = (type_child.find("input[name=type-link]").is(":checked")) ? "siblings" : "child";

			var type_child_node = exportChildNodeLoop(type_child_ID);
			if (type_child_node != "") {
				// type_child_node = type_child_node.substring(0, type_child_node.length - 1);
				type_child_node = type_child_node.split(",");
			}
			var type_child_req = type_child_node.length;

			data["child"][type_child_ID] = {
				"title": type_child_title,
				"id": type_child_ID,
				"helper": type_child_info,
				"req": type_child_req,
				"node": type_child_node,
				"type": type_child_type,
				"view": type_child_view
			}


			if (type_child_type == "siblings" || type_child_type == "child") {
				data["child"][type_child_ID]["data"] = extractData(type_child_ID, type_child.find(".type-form").serializeArray());
			} else if (type_child_type == "link")
				data["child"][type_child_ID]["url"] = type_child.find("input[name=param-url]").val()
		})
		

		 var id = $.gritter.add({
            title:"Export", 
            text: "en cours",
            image: 'http://betty.excentrik.fr/mnk-include/core/img/ui/fff/48px/clock2.png',
            sticky: true,
            time: ''
        });

		$("body").addClass("onLoad");
		$.post(url, data, function(data) {
			$.gritter.add({
				title: "Export",
				text: "my-rocket OK",
				image: 'http://betty.excentrik.fr/mnk-include/core/img/ui/fff/48px/checkmark.png',
				sticky: false,
				time: '250'
			});
			$.gritter.remove(id)
			$("body").removeClass("onLoad");
		})

		return false;
	})

	function exportChildNodeLoop(idParent,level) {
		var childList = "";
		var level 		= (level==null)?0:level
		var idChild = extractChildNode(idParent);

		if (idChild != "") {

			childSplite = idChild.split(";");
			// console.log(childList);
			$.each(childSplite, function(key, val) {
				childList += "[" + val;
				var list = exportChildNodeLoop(val,level+1);
				if (list) {

					childList += list;
				}

				childList += "]";
			})
		}



		return childList;
	}

	function extractChildNode(idParent) {
		var idChild = $("#" + idParent).find(".rocket-param-hook-to-child").attr("reldraw");
		if (idChild) {

			var idChild = idChild.split("--");
			idChild = idChild.splice(0, idChild.length - 1);
			var childList = "";
			$.each(idChild, function(key, val) {
				var childSplit = val.split(",");
				childList += childSplit[2].replace(new RegExp("-toParent", "g"), '') + ";";
			})
			childList = childList.substring(0, childList.length - 1);
			return childList;
		} else {
			return "";
		}
	}


	function extractData(id, dataToExtract) {
		var data = new Array();

		$.each(dataToExtract, function(key, val) {

			if (val.name == id + "-data[]")
				data.push(val.value);
		})


		return data;
	}

	$("#addP").on('click', function() {
		var t = $(this);
		addParamReq()

	});

	function addParamReq() {
		var list = $('.type-1 .speed-param-info.mnk-tab');

		$.each(list, function() {
			var t = $(this);
			var input = $('<input>', {
				"type": "text",
				"class": "req input-ico placeholder-no-fix",
				"name": "param-req",
				"value": "1"
			}).css({
				"background-image": "url(http://metronic.excentrik.fr/mnk-include/core/img/svg/compass.svg)"
			});
			t.prepend(input);
			// console.log(input);
		})
	}


	$('#param-rocket-new').click(function() {
		$(".layer").html(" ");
		$("#rocket-param-select-all").trigger("click");
		$("#rocket-param-delete").trigger("click");


	})


	$("#rocket-param-delete").click(function() {
		if (confirm('Êtes-vous certain de vouloir supprimer les elements selectionnés ?'))
			$(".layer .onSelectDrag").fadeOut(150, function() {
				var t = $(this);
				t.remove();
				var idDrawLinked = t.find(".rocket-param-hook").attr("reldraw");
				var drawList = idDrawLinked.split('--');
				//				console.log(drawList);
				// if (idDrawLinked){

				$.each(drawList, function(index, val) {
					attributeLinkRemove(val)

				});
				// }

			});

	});


	function attributeLinkRemove(rel) {

		var list = rel.split(",");

		var drawId = list[0];

		var start = $("#" + list[1]);
		var pStart = start.parents(".elem");
		var finish = $("#" + list[2].replace("--", ""));
		var pfinish = finish.parents(".elem");

		startAttr = start.attr("reldraw");
		pStartAttr = pStart.attr("reldraw");
		finishAttr = finish.attr("reldraw");
		pfinishAttr = pfinish.attr("reldraw");



		start.attr("reldraw", startAttr.replace(rel, ""));
		pStart.attr("reldraw", pStartAttr.replace(rel, ""));
		finish.attr("reldraw", finishAttr.replace(rel, ""));
		pfinish.attr("reldraw", pfinishAttr.replace(rel, ""));



		var connected = parseInt(start.find(".rocket-param-hook-connect").html());
		start.find(".rocket-param-hook-connect").html(connected - 1);


		$("#" + drawId).remove();
	}



	$("#uploader").toggle(function() {
			var uploader = $("<div>", {
				id: 'drop-zone'
			})
			$("svg").before(uploader);
		},
		function() {
			$("#drop-zone").remove();
		});

	$(".rocket-type-add").on("click", function(e) {
		var t = $(this);
		var type = t.attr("href");



		createType(type, type, e.pageX, e.pageY);
	});



	function lastId() {

		var idList = [];
		var paramList = $('.layer .rocket-param-edit');
		$.each(paramList, function() {
			var t = $(this);
			idList.push(parseInt(t.attr("id").replace("e", "")));
		})

		var lastId = (paramList.length > 0) ? Math.max.apply(Math, idList) : 0;

		return lastId;
	}

	function createType(type, title, left, top) {



		var posLayer = $(".layer").offset();
		var model = $("#model " + type);
		var clone = model.clone();
		var w = model.outerWidth();
		var h = model.outerHeight();
		var posLeft = left - posLayer.left;
		var posTop = top - posLayer.top;
		clone.show().css({
			"left": posLeft,
			"top": posTop
		}).keyup(function(e) {
			var t = $(this);
			speedParam(t);
		});

		var cloneId = "e" + (lastId() + 1);



		clone.attr({
			"id": cloneId
		});
		clone.removeClass("hide");
		clone.removeClass("rocket-param-model");
		clone.find(".rocket-param-hook-to-child").attr("id", cloneId + "-toChild");
		clone.find(".rocket-param-hook-to-parent").attr("id", cloneId + "-toParent");
		clone.find(".type-id").html(cloneId);
		clone.find(".type-title").val(title).attr("value", title);

		clone.drop("start", function() {
			$(this).addClass("onHoverDrop");
		})
			.drop(function(ev, dd) {
				$(this).toggleClass("onSelectDrag");
			})
			.drop("end", function() {
				$(this).removeClass("onHoverDrop");
				//				/*console.log("drop end");*/
			}).on("mouseenter", function() {
				$("body").addClass("offDrag");
			}).on("mouseleave", function() {
				$("body").removeClass("offDrag");
			});

		$(".layer").append(clone);


		clone.find("a.speed-param-info").trigger("click")
		clone.find("input.type-title").val("").focus()

		if (type == "#new-type-2") {
			// console.log("this");
			clone.find(".form-toggle").trigger('click');
		}

		return cloneId;
	}



	$(document).on("click", '.speed-param-child', function() {
		var t = $(this);
		var p = t.parents(".rocket-param-edit");
		var selectSpeed = p.find("ol li.onParamSelect");


		$.each(selectSpeed, function() {
			var tP = $(this);
			var type = "#new-type-2";
			var posTp = tP.offset();
			var title = tP.find(".speed-data").val();
			var id = createType(type, title, posTp.left + tP.width(), posTp.top);

			$("#" + id + " .form-toggle-slide").trigger("mouseup")
			// console.log(id);
		})

	})



	$(' a.rocket-align').click(function() {

		var t = $(this);
		var id = t.attr("id");
		var onSelectDrag = $(".onSelectDrag");

		var animateTime = 125;

		var left = new Array();
		var top = new Array();
		// var height = new Array();
		// var width = new Array();

		var marginRight = 75;
		var marginBottom = 10;

		var height = 75;
		var width = onSelectDrag.width();



		$.each(onSelectDrag, function(index, val) {

			var t = $(this);
			var pos = t.position();

			//			console.log(pos);

			var elemLeft = pos.left;
			var elemTop = pos.top;


			// var elemHeight = parseInt(t.css("height"));
			left.push(elemLeft);
			// right.push(elemRight);
			top.push(elemTop);
			// width.push(elemWidth);

		})


		if (id == "rocket-align-left") {
			var max = Math.max.apply(null, left); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, left);
			onSelectDrag.stop().animate({
				left: min
			}, animateTime);

		} else if (id == "rocket-align-right") {
			var max = Math.max.apply(null, left); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, left);


			var pRight = max;

			onSelectDrag.stop().animate({
				left: pRight
			}, animateTime);

			//			console.log(min);
			//			console.log(max);
			//			console.log(pRight);
		} else if (id == "rocket-align-center-horizontal") {
			var max = Math.max.apply(null, left); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, left);



			var center = min + (max - min) / 2;

			onSelectDrag.stop().animate({
				left: center
			}, animateTime);

		} else if (id == "rocket-align-center-vertical") {
			var max = Math.max.apply(null, top); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, top);


			var center = min + (max - min) / 2;

			onSelectDrag.stop().animate({
				top: center
			}, animateTime);

		} else if (id == "rocket-align-bottom") {
			var max = Math.max.apply(null, top); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, top);

			onSelectDrag.stop().animate({
				top: max
			}, animateTime);

		} else if (id == "rocket-align-top") {
			var max = Math.max.apply(null, top); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, top);

			onSelectDrag.stop().animate({
				top: min
			}, animateTime);

		} else if (id == "rocket-align-list-vertical") {
			var max = Math.max.apply(null, top); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, top);



			var i = 0;

			var posTop = min;
			$.each(onSelectDrag, function(index, val) {
				var posTop = min + (height + marginBottom) * i;
				$(this).stop().animate({
					top: posTop
				}, animateTime);
				i++;
			});


		} else if (id == "rocket-align-list-horizontal") {
			var type1 = $(".onSelectDrag.type-1, .onSelectDrag.type-0");

			var max = Math.max.apply(null, left); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, left);
			$.each(type1, function(key, val) {
				var t = $(this);
				var child = exportChildNodeLoop(t.attr("id"));
				child = child.substring(1,child.length)
				var child = child.split("[");
				// console.log(child);
				var pos = t.offset();
				var tW = t.width();
				var leftStart = pos.left + tW + marginRight;
				$.each(child, function(key, val) {
					val  = val.replace(new RegExp("]", "g"), '');
					var tChild = $("#" + val);
					tChild.addClass("onSelectDrag");
					tChild.animate({
						"left": leftStart,
						"top": pos.top + 3
					}, animateTime);
					leftStart = leftStart + tChild.width() + marginRight;
					// console.log(leftStart);
				})
				// $(".onSelectDrag").removeClass("onSelectDrag");
				// type1.addClass("onSelectDrag");

			})


			// var i = 0;

			// var posTop = min;
			// $.each(onSelectDrag, function(index, val) {
			// 	var width = $(this).width();
			// 	var posLeft = min + (width + marginRight) * i;
			// 	$(this).stop().animate({
			// 		left: posLeft
			// 	}, animateTime);
			// 	i++;
			// });


		} else if (id == "rocket-align-grid") {
			var max = Math.max.apply(null, left); /* This about equal to Math.max(numbers[0], ...) or Math.max(5, 6, ..) */
			var min = Math.min.apply(null, left);



			var i = 0;

			var posTop = min;
			$.each(onSelectDrag, function(index, val) {
				var tDrag = $(this);
				var width = $(this).outerWidth() + marginRight;

				var pos = $(this).offset()
				var posLeft = Math.round(pos.left / width) * width;
				var posTop = (Math.round(pos.top / height) * height) - height * 2;
				$(this).stop().animate({
					left: posLeft,
					top: posTop
				}, animateTime);
				i++;
			});



		}
		setTimeout(function() {
			moveDrawLinkedByAlign()
		}, animateTime)

		if ($(this).attr("relDraw")) {


			fusionList = $(this).attr("relDraw").split(" ")

			$.each(fusionList, function(index, val) {
				var draw = $("#" + val);
				if (draw.length == 1) {
					var rel1 = draw.attr("rel1");
					var rel2 = draw.attr("rel2");
					posA = $("#" + rel1).offset();
					posB = $("#" + rel2).offset();
					var layerPos = $("svg").offset();

					var hookH = $("#" + rel1).outerHeight() / 2;
					var hookW = $("#" + rel1).outerWidth() / 2;

					draw.attr({
						'x1': posA.left - layerPos.left + hookW,
						'y1': posA.top - layerPos.top + hookH,
						'x2': posB.left - layerPos.left + 4,
						'y2': posB.top - layerPos.top + hookH
					});
				}

			});
		}

		return false;
	})

	$(document)
		.drag("start", function(ev, dd) {
			if (!$("body").hasClass("offDrag")) {
				if ($('#rocket-param-select').hasClass("toggled-on")) {
					if (!$("body").hasClass("onAltCmd")) {
						$(".onSelectDrag").removeClass("onSelectDrag");
						$(".selection").remove()
					}
					return $('<div class="selection" />').appendTo(document.body);
				}
			}
		})
		.drag(function(ev, dd) {
			$(dd.proxy).css({
				top: Math.min(ev.pageY, dd.startY),
				left: Math.min(ev.pageX, dd.startX),
				height: Math.abs(ev.pageY - dd.startY),
				width: Math.abs(ev.pageX - dd.startX)
			});
		})
		.drag("end", function(ev, dd) {

			// $(".dropped").toggleClass("active")
			$(dd.proxy).remove();
		});



	$('.rocket-param-edit')
		.drop("start", function() {
			$(this).addClass("onHoverDrop");

			//			/*console.log("start");*/
		})
		.drop(function(ev, dd) {

			$(this).toggleClass("onSelectDrag");


			//			/*	console.log("drop");*/
		})
		.drop("end", function() {
			$(this).removeClass("onHoverDrop");
			//			/*console.log("drop end");*/
		}).on("mouseenter", function() {
			$("body").addClass("offDrag");
		}).on("mouseleave", function() {
			$("body").removeClass("offDrag");
		});

	$.drop({
		multi: true
	});



	var shortKey = {
		86: "rocket-param-select",
		68: "rocket-param-unselect",
		107: "rocket-param-plus",
		65: "rocket-param-select-all",
		96: "rocket-align-list-horizontal",
		39: "move-right",
		73: "rocket-param-select-toggle",
		103: "rocket-align-left",
		105: "rocket-align-right",
		104: "rocket-align-center-horizontal",
		40: "move-down",
		38: "move-up",
		37: "move-left"
	};

	$(document).on("click", "a.speed-param", function() {
		var t = $(this);
		var meta = $("<div>", {
			"class": "meta-count"
		});
		var textarea = t.parents('.rocket-param-edit').find("textarea");


		var val = textarea.val().split("\n");

		var ol = t.parents('.rocket-param-edit').find("ol.data");
		var pID = t.parents('.rocket-param-edit').attr("id");
		var i = ol.find("li").length;
		$.each(val, function(key, val) {
			i++;
			if (val != "") {
				var hook = $("<div>", {
					"id": pID + "-toChildSingle" + key,
					"class": "rocket-param-hook-to-child-single rocket-param-hook"
				})
				var input = $("<input>", {
					"name": pID + "-data[]",
					"class": "speed-data",
					"value": val
				}).val(val);
				var li = $("<li>").prepend(input).append(hook);
				ol.append(li)
			}
		})
		textarea.val("").html("");
		if (t.find(".meta-count").length == 0)
			t.prepend(meta.html(i - 1))
		else
			t.find(".meta-count").html(i - 1)
		return false;
	})



	$(document).on("click", ".speed-param-delete", function() {
		$(this).parents('.rocket-param-edit').find("ol.data .onParamSelect").remove();
		return false;
	})

	$(document).on("keyup", ".rocket-param-edit input", function(e) {

		var shortKeyList = [37, 39, 13, 16, 9];

		var eval = $.inArray(e.keyCode, shortKeyList);
		if (eval < 0) {
			var t = $(this);
			t.attr("value", t.val());
		}

	})
	$(document).on("keyup", ".rocket-param-edit textarea", function(e) {
		var shortKeyList = [37, 39, 13, 16, 9];
		var eval = $.inArray(e.keyCode, shortKeyList);
		if (eval < 0) {
			var t = $(this);
			t.html(t.val());
		}
	})


	$(document).on("click", ".rocket-param-edit", function(e) {
		$(".super-zindex").removeClass("super-zindex")
		$(this).addClass('super-zindex');

	})



	$(document).on("click", "ol.data li", function() {
		if ($(this).parents(".rocket-param-edit").find(".speed-param-select").hasClass("toggled-on"))
			$(this).toggleClass("onParamSelect")
	})
	$(document).on('click', ".menu-mini a.toggled", function() {
		var t = $(this);
		t.toggleClass("toggled-on");
		t.parents(".rocket-param-edit").find(".onParamSelect").removeClass('onParamSelect')

		return false;
	});

	$(document).on('dblclick', ".speed-param-select", function() {
		$(this).parents(".rocket-param-edit").find("ol.data li").toggleClass('onParamSelect')

	});

	$(document).on('mouseup', ".menu-mini .form-toggle", function() {
		var t = $(this).find(".form-toggle-slide");
		var elem = t.parents(".rocket-param-edit");
		var hook = elem.find(".rocket-param-hook");
		var bgcOff = t.find(".off").css("background-color")
		var bgcOn = t.find(".on").css("background-color")
		if (t.hasClass('form-toggle-off')) {
			hook.css("background-color", bgcOff);
			elem.find("ol.data").css("border-color", bgcOff)
			elem.addClass("rocket-child").removeClass('rocket-sibling');
			elem.find(".rocket-param-hook-to-child").addClass('rocket-param-hook-disabled').css("background-color", "#ccc");
		} else {
			elem.removeClass("rocket-child").addClass('rocket-sibling');
			elem.find("ol.data").css("border-color", bgcOn)
			hook.css("background-color", bgcOn);
			elem.find(".rocket-param-hook-to-child").removeClass('rocket-param-hook-disabled');
		}
		// 	var bgc = t.find(".off").css("background-color")
		// else 
		// 	var bgc = t.find(".on").css("background-color");



	});

	function moveDrawLinkedByToggle(idParent) {
		var onSelectDrag = $(".onSelectDrag");
		$.each(onSelectDrag, function(index, val) {
			moveDrawLinkedByThis($(this));
		})
	}


	function moveDrawLinkedByAlign() {
		var onSelectDrag = $(".onSelectDrag");
		$.each(onSelectDrag, function(index, val) {
			moveDrawLinkedByThis($(this));
		})
	}


	function moveDrawLinkedByThis(t) {
		if (t.attr("relDraw")) {
			fusionList = t.attr("reldraw").split("--")
			$.each(fusionList, function(index, val) {
				var obj = val.split(",");
				var draw = $("#" + obj[0]);
				if (draw.length == 1) {
					var rel1 = draw.attr("rel1");
					var rel2 = draw.attr("rel2");
					posA = $("#" + rel1).offset();
					posB = $("#" + rel2).offset();
					var layerPos = $("svg").offset();

					var hookHA = $("#" + rel1).outerHeight() / 2;
					var hookWA = $("#" + rel1).outerWidth();

					var hookHB = $("#" + rel2).outerHeight() / 2;
					var hookWB = $("#" + rel2).outerWidth();


					draw.attr({
						'x1': posA.left - layerPos.left + hookWA,
						'y1': posA.top - layerPos.top + hookHA,
						'x2': posB.left - layerPos.left + 4,
						'y2': posB.top - layerPos.top + hookHB
					});
				}

			});
		}
	}
function createForThis(t){

			if (t.attr("reldraw")) {

				if(t.attr("reldraw")=="--draw_29,e19-toChild,e18-toParent--")
					t.attr("reldraw","draw_29,e19-toChild,e18-toParent--")


				var drawList = t.attr("reldraw");
				var drawList =	drawList.substring(0,drawList.length-2)
				var drawSplite = drawList.split("--");

// console.log(t.attr("reldraw"));
// $("#e18").addClass("onSelectDrag").show();

				// if(drawSplite[0]=="")
				// 	console.log(t.parents(".rocket-param-edit").attr("id"));



// console.log(drawSplite);
				$.each(drawSplite, function(index, val) {

					if (val != "") {
						var obj = val.split(",");
				

						var idDraw = obj[0];
						if ($("#" + idDraw).length < 1) {
							var start = $("#" + obj[1]);
							var finish = $("#" + obj[2]);
							var posA = start.offset();
							var posB = finish.offset();

							var layerPos = $("svg").offset();
							var hookHA = start.outerHeight() / 2;
							var hookWA = start.outerWidth();

							var hookHB = finish.outerHeight() / 2;
							var hookWB = finish.outerWidth();
							var color = start.css("background-color");
							//var color = "#a6a6a6";
							// console.log(pos);
							var svg = $("svg");

							var x1 = posA.left - layerPos.left + hookWA;
							var y1 = posA.top - layerPos.top + hookHA;

							var x2 = 5 - layerPos.left + 4;
							var y2 = 5 - layerPos.top + hookHB;


							/* DUPLICATE*/
							// var x2 = posB.left - layerPos.left + 4;
							// var y2 = posB.top - layerPos.top + hookHB;
							/**/


							var newLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
							newLine.setAttribute('id', idDraw);
							newLine.setAttribute('class', 'line type-0');
							newLine.setAttribute('x1', x1);
							newLine.setAttribute('y1', y1);
							newLine.setAttribute('x2', x2);
							newLine.setAttribute('y2', y2);
							newLine.setAttribute('rel1', obj[1]);
							newLine.setAttribute('rel2', obj[2]);

							svg.append(newLine);




							// $("#" + idDraw).css({
							// 	"stroke-width": 3
							// })


						}
					}
				})

				// v

			}
}


	function createLineForLoad() {
		var hook = $('.rocket-param-hook');
		$.each(hook, function() {
				var t = $(this);
				createForThis(t)
		})



	}


	$(".move").on("click", function() {
		var t = $(this);
		var value = 10;
		var sens = t.attr("href").replace("#", "");


		var onSelectDrag = $(".onSelectDrag");
		var layer = $(".layer").offset();


		$.each(onSelectDrag, function(index, val) {
			var elem = $(this);
			var pos = elem.position();


			if (sens == "right")
				elem.css("left", pos.left + value)
			else if (sens == "left")
				elem.css("left", pos.left - value)
			else if (sens == "up")
				elem.css("top", pos.top - value)
			else if (sens == "down")
				elem.css("top", pos.top + value)
			else {
				elem.css({
					left: layer.left + 100,
					top: layer.top + 100
				})
			}
			moveDrawLinkedByThis(elem)
		});



		return false;
	});

	$(document).on("click", "a.toggle-me", function() {
		if ($("body").hasClass("onAltAlt")) {
			$.$.each($(".onSelectDrag"), function(index, val) {
				var t = $(this);
				t.find("a.toggle-me").trigger('click');
			});
		}


		$(this).parents(".rocket-param-edit").toggleClass('toggle-me-on');
		moveDrawLinkedByThis($(this).parents(".rocket-param-edit"))
		return false;
	})

	$(".range-div input").on("change", function() {
		var t = $(this);

		var layer = $(".layer, svg");
		var zoom = t.val() / 100;
		layer.css({
			'transform': 'scale(' + zoom + ')',
			'transform-origin': '0 0'

		})
	})

	$(document).on("keydown", function(e) {

		if ($("body").hasClass('onAltMaj')) {
			var eval = e.keyCode in shortKey;
			if (eval) {
				$("#" + shortKey[e.keyCode]).trigger("click");
				//return false;
			}
		}
	})


	$('#loading-param').trigger("click")
	$("#rocket-param-select").trigger('click');

	$(document).on("dblclick", ".rocket-param-edit", function() {
		var t = $(this);

		var tPos = t.offset();
		var time = 500;

		var draw = t.find(".rocket-param-hook-to-child").attr("reldraw");
		if (draw) {
			// console.log(draw);
			// var val = val.replace(new RegExp("]", "g"), '');
			draw = draw.split("--");
			$.each(draw,function (key,val){
				var val = val.split(",");
				// $("#" + val[0]).toggle();
			})
			
			// 
		}

		t.toggleClass("toggle-group");
		var child = exportChildNodeLoop(t.attr("id"));

		var child = child.split("[");

		if (t.hasClass("toggle-group")) {
			var meta = $("<div>", {
				"class": "rocket-param-meta-count"
			}).css({
				"position": "absolute",
				"margin-left": t.outerWidth()
			}).html(child.length - 1)
			t.prepend(meta);

		} else {
			t.find(".rocket-param-meta-count").remove();
		}


		$.each(child, function(key, val) {
			var val = val.replace(new RegExp("]", "g"), '');
			var c = $("#" + val);
			// var cPos = c.offset();
			var draw = c.find(".rocket-param-hook-to-child").attr("reldraw");
			if (draw) {
				draw = draw.substring(0,draw.length-2).split("--");
				$.each(draw,function (key,val){
					var val = val.split(",");
					if (t.hasClass("toggle-group")){

						$("#" + val[0]).hide();

					}
					else {
						$("#" + val[0]).show();
					}
				});

			}



			if (t.hasClass("toggle-group")){

					c.hide();
					

				}
				else {
					c.show();

					
				}
				// setTimeout(function (){
						moveDrawLinkedByThis(c);
					// },20)
		})
		setTimeout(function (){
			moveDrawLinkedByThis(t);
			// console.log(c.offset());
		},20)

	})









});