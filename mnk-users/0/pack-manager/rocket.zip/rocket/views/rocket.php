<input type="text" class="rocket"/>
<?php mnk::css("pack:rocket/rocket"); ?>
<?php mnk::js("pack:rocket/rocket"); ?>