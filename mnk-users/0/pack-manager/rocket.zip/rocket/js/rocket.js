$(document).ready(function(){

	var url = "http://metronic.excentrik.fr/mnk-users/0/rocket/scan-pack.json";
	$.getJSON(url,function (data){
		console.log(data);

		$('input.rocket').on("keyup",function(e){
		var t = $(this);

		var launcher = $('#rocket-launcher').find("ul");

		launcher.html("");


		var find = t.val();
		$.each(data, function(index, val) {
			






	if (find == val) {
			var li = $("<li>",{"class":"launcher"});
	
			li.html(val);


			launcher.append(li);
	}
		
		});

		navKey(e);	
	})
	.on('keydown',function(e){
		
	})
	.on('focusin',function (){
		var launcher = $("<div>",{"id":"rocket-launcher","class":"rocket-list"}).html("<ul></ul>");
		$(this).after(launcher);
	})
	.on('focusout',function (){
		var t = $(this);
		t.val("");
		$('#rocket-launcher').fadeOut(350, function (){
			$(this).remove();
		})
	});



function navKey(e){

// console.log(e.keyCode);
	if(e.keyCode == "40")
		$('li.launcher').addClass('onSelect');

	else if (e.keyCode == "38"){
$('li.launcher').addClass('onSelect');
	}
		
	else if (e.keyCode == "13")
		$('li.launcher.onSelect').trigger('click');


// 	else 
// 		console.log(e.keyCode);

}

	$(document).on("click","li.launcher",function(){
		var t = $(this);
		var type = t.html()
alert(type);
		console.log(type);
	});
	});




});