<div class="ingrid">
<?php form::iform("pack-exec:thief/thief-save-get #thiefOnLive");?>
<?php form::text("first","first","814"); ?>
<?php form::text("last","last","1351"); ?>
<?php form::text("title","title","commerce"); ?>
<hr>
<?php form::submit("scan","scan"); ?>
<?php form::formOut();?></div>