<?php 
// define(name, value);
 ?>