<?php
class [PACK] extends mnk {

	function [PACK]()


    }

?>