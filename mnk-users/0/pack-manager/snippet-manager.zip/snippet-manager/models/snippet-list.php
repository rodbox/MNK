<?php 

$d = file::listDir(DIR_SNIPPETS);

/*
$i = 0;
foreach ($snippetFolderScan as $key => $value) {

	$d["snippet"][$i] = file::file_list($value);
	$snippet = $d["snippet"][$i][2];


mnk::debug($d["snippet"]);

	rename( $value."/".$snippet, DIR_SNIPPETS."/".$snippet);
	$i++;
	echo $value."/".$snippet;
	# code...
}*/

 ?>