<?php mnk::js("pack:test/test"); ?>

