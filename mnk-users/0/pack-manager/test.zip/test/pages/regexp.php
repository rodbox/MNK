<?php mnk::js("pack:test/regexp"); ?>

<h3>test regexp <span class="small">(by js)</span></h3>
<div class="evalReg">
	<?php form::text("regexp","regexp","a[a-z]{0,}c"); ?>
	<?php form::text("str","str","abc"); ?>
</div>
<div class="resultExp"></div>
