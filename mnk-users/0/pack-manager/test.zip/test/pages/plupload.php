<?php mnk::js( "core:jquery.mnk-plupload"); ?>


<?php mnk::plupload("pack-exec:gal/gal-upload"); ?>