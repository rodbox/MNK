$(document).ready(function(){


	

$('.evalReg input').on("keyup",function(){
	var str = $('input[name=str]').val();	
	var regexp = $('input[name=regexp]').val();	

	var patt = new RegExp(regexp);
	var eval = patt.test(str);
	var msg = (eval)?"ok":"false";
		
	$('.resultExp').html(msg);



})


	

});