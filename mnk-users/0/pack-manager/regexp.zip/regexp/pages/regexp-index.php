<div class="row-fluid">
	<div class="span12">
	

	</div>
</div>
<?php mnk::css("pack:[PACK]/[PACK]"); ?>
<?php mnk::js("pack:[PACK]/[PACK]"); ?>