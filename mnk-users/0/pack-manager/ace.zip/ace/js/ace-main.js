$(document).ready(function(){
	$(document).on("click",".demo",function(){
		alert("jklm");
	$('#my-code-area').ace({ theme: 'twilight', lang: 'javascript' });	
	})
	 
});